# deteksi-kendaraan > 2024-04-03 8:35am
https://universe.roboflow.com/yostar465/deteksi-kendaraan-3ip7b

Provided by a Roboflow user
License: CC BY 4.0

